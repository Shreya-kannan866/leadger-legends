// server.js
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const farmerRoutes = require('./routes/farmerRoutes');
const distributorRoutes = require('./routes/distributorRoutes');
const retailerRoutes = require('./routes/retailerRoutes');
const consumerRoutes = require('./routes/consumerRoutes');

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.use('/farmer', farmerRoutes);
app.use('/distributor', distributorRoutes);
app.use('/retailer', retailerRoutes);
app.use('/consumer', consumerRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`✅ Backend running at http://localhost:${PORT}`);
});
