const express = require("express");
const router = express.Router();
const contract = require("../blockchain");

// Retailer updates sales info
router.post("/sales", async (req, res) => {
  try {
    const { batchId, retailQuantity, retailPurchasePrice, consumerPrice } = req.body;
    const tx = await contract.updateRetail(batchId, retailQuantity, retailPurchasePrice, consumerPrice);
    await tx.wait();
    res.json({ success: true, txHash: tx.hash });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
