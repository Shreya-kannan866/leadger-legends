const express = require("express");
const router = express.Router();
const contract = require("../blockchain");  // Person B’s blockchain connector

// Farmer creates a new produce batch
router.post("/harvest", async (req, res) => {
  try {
    const { cropType, quantity, location, price } = req.body;
    const tx = await contract.createProduce(cropType, quantity, location, price);
    await tx.wait();
    res.json({ success: true, txHash: tx.hash });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
