const express = require('express');
const { getFarmerData } = require('../controllers/farmerController');

const router = express.Router();

router.get('/:batchID', getFarmerData);

module.exports = router;
