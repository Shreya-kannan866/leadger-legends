const express = require("express");
const router = express.Router();
const contract = require("../blockchain");

// Consumer traces produce batch
router.get("/trace/:batchId", async (req, res) => {
  try {
    const batchId = req.params.batchId;
    const produce = await contract.getProduce(batchId);
    res.json(produce);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
