// routes/distributorRoutes.js
const express = require('express');
const { provider } = require('../eth');

const router = express.Router();

router.post('/update', async (req, res) => {
  try {
    const { txHash } = req.body;

    if (!txHash) {
      return res.status(400).json({ error: 'Provide txHash from frontend transaction' });
    }

    const receipt = await provider.waitForTransaction(txHash, 1, 180000);
    if (!receipt) return res.status(500).json({ error: 'Transaction not mined in time' });

    res.json({ message: '✅ Distribution update acknowledged', txHash });
  } catch (err) {
    console.error('distributor/update error:', err);
    res.status(500).json({ error: err.message || 'Internal server error' });
  }
});

module.exports = router;

