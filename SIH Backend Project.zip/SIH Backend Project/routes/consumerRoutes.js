// routes/consumerRoutes.js
const express = require('express');
const { contract, ethers } = require('../eth');

const router = express.Router();

router.get('/:batchId', async (req, res) => {
  try {
    const { batchId } = req.params;
    if (!batchId) return res.status(400).json({ error: 'batchId required' });

    const produce = await contract.getProduce(ethers.BigNumber.from(batchId));

    // Convert BigNumbers & nested objects
    function convert(obj) {
      if (ethers.BigNumber.isBigNumber(obj)) return obj.toString();
      if (Array.isArray(obj)) return obj.map(convert);
      if (obj && typeof obj === 'object') {
        const out = {};
        for (const k of Object.keys(obj)) {
          if (!isNaN(k)) continue;
          out[k] = convert(obj[k]);
        }
        return out;
      }
      return obj;
    }

    res.json({ batchId, produce: convert(produce) });
  } catch (err) {
    console.error('consumer error:', err);
    res.status(500).json({ error: err.message || 'Internal server error' });
  }
});

module.exports = router;

