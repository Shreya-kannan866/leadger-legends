// routes/farmerRoutes.js
const express = require('express');
const QRCode = require('qrcode');
const { provider, contract, ethers } = require('../eth');

const router = express.Router();

// POST /farmer/create
// Body: { txHash: "0x...", batchIdFromFrontend?: "1" }
router.post('/create', async (req, res) => {
  try {
    const { txHash, batchIdFromFrontend } = req.body;

    if (!txHash) {
      return res.status(400).json({ error: 'Provide txHash from frontend transaction' });
    }

    // wait for tx confirmation
    const receipt = await provider.waitForTransaction(txHash, 1, 180000);
    if (!receipt) return res.status(500).json({ error: 'Transaction not mined in time' });

    // Extract batchId from ProduceCreated event
    let batchId = null;
    for (const log of receipt.logs) {
      try {
        const parsed = contract.interface.parseLog(log);
        if (parsed && parsed.name === 'ProduceCreated') {
          batchId = parsed.args.batchId?.toString() || parsed.args[0]?.toString();
          break;
        }
      } catch (e) {
        // skip unrelated logs
      }
    }

    // fallback
    if (!batchId) {
      if (batchIdFromFrontend) batchId = String(batchIdFromFrontend);
      else {
        const counter = await contract.batchCounter();
        batchId = counter.toString();
      }
    }

    const consumerUrl = `${process.env.BASE_URL || 'http://localhost:5000'}/consumer/${batchId}`;
    const qr = await QRCode.toDataURL(consumerUrl);

    res.json({
      message: '✅ Produce registered',
      batchId,
      txHash,
      qr,
      consumerUrl
    });
  } catch (err) {
    console.error('farmer/create error:', err);
    res.status(500).json({ error: err.message || 'Internal server error' });
  }
});

module.exports = router;

