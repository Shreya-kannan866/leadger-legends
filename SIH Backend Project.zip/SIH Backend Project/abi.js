// abi.js
module.exports = [
  {
    "anonymous": false,
    "inputs": [
      { "indexed": false, "internalType": "uint256", "name": "batchId", "type": "uint256" },
      { "indexed": false, "internalType": "address", "name": "distributor", "type": "address" }
    ],
    "name": "Distributed",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      { "indexed": false, "internalType": "uint256", "name": "batchId", "type": "uint256" },
      { "indexed": false, "internalType": "address", "name": "farmer", "type": "address" }
    ],
    "name": "ProduceCreated",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      { "indexed": false, "internalType": "uint256", "name": "batchId", "type": "uint256" },
      { "indexed": false, "internalType": "address", "name": "retailer", "type": "address" }
    ],
    "name": "RetailUpdated",
    "type": "event"
  },
  {
    "inputs": [],
    "name": "batchCounter",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "string", "name": "farmerName", "type": "string" },
      { "internalType": "string", "name": "cropType", "type": "string" },
      { "internalType": "uint256", "name": "quantity", "type": "uint256" },
      { "internalType": "uint256", "name": "pricePerKg", "type": "uint256" },
      { "internalType": "string", "name": "location", "type": "string" }
    ],
    "name": "createProduce",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "address", "name": "", "type": "address" },
      { "internalType": "uint256", "name": "", "type": "uint256" }
    ],
    "name": "farmerBatches",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "farmer", "type": "address" }],
    "name": "getFarmerBatches",
    "outputs": [{ "internalType": "uint256[]", "name": "", "type": "uint256[]" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "getLatestBatchId",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "uint256", "name": "batchId", "type": "uint256" }],
    "name": "getProduce",
    "outputs": [
      {
        "components": [
          {
            "components": [
              { "internalType": "string", "name": "farmerName", "type": "string" },
              { "internalType": "string", "name": "cropType", "type": "string" },
              { "internalType": "uint256", "name": "quantity", "type": "uint256" },
              { "internalType": "uint256", "name": "pricePerKg", "type": "uint256" },
              { "internalType": "string", "name": "location", "type": "string" },
              { "internalType": "uint256", "name": "createdDate", "type": "uint256" },
              { "internalType": "address", "name": "farmer", "type": "address" }
            ],
            "internalType": "struct SupplyChainTracker.FarmerInfo",
            "name": "farmerInfo",
            "type": "tuple"
          },
          {
            "components": [
              { "internalType": "string", "name": "distributorName", "type": "string" },
              { "internalType": "uint256", "name": "quantityReceived", "type": "uint256" },
              { "internalType": "uint256", "name": "purchasePrice", "type": "uint256" },
              { "internalType": "string", "name": "transportDetails", "type": "string" },
              { "internalType": "string", "name": "warehouseLocation", "type": "string" },
              { "internalType": "uint256", "name": "handoverDate", "type": "uint256" },
              { "internalType": "uint256", "name": "distributedDate", "type": "uint256" },
              { "internalType": "address", "name": "distributor", "type": "address" }
            ],
            "internalType": "struct SupplyChainTracker.DistributorInfo",
            "name": "distributorInfo",
            "type": "tuple"
          },
          {
            "components": [
              { "internalType": "string", "name": "retailerName", "type": "string" },
              { "internalType": "string", "name": "shopLocation", "type": "string" },
              { "internalType": "uint256", "name": "retailQuantity", "type": "uint256" },
              { "internalType": "uint256", "name": "retailPurchasePrice", "type": "uint256" },
              { "internalType": "uint256", "name": "consumerPrice", "type": "uint256" },
              { "internalType": "uint256", "name": "expiryDate", "type": "uint256" },
              { "internalType": "uint256", "name": "retailDate", "type": "uint256" },
              { "internalType": "address", "name": "retailer", "type": "address" }
            ],
            "internalType": "struct SupplyChainTracker.RetailInfo",
            "name": "retailInfo",
            "type": "tuple"
          },
          { "internalType": "enum SupplyChainTracker.Stage", "name": "stage", "type": "uint8" }
        ],
        "internalType": "struct SupplyChainTracker.Produce",
        "name": "",
        "type": "tuple"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "name": "produceItems",
    "outputs": [
      {
        "components": [
          { "internalType": "string", "name": "farmerName", "type": "string" },
          { "internalType": "string", "name": "cropType", "type": "string" },
          { "internalType": "uint256", "name": "quantity", "type": "uint256" },
          { "internalType": "uint256", "name": "pricePerKg", "type": "uint256" },
          { "internalType": "string", "name": "location", "type": "string" },
          { "internalType": "uint256", "name": "createdDate", "type": "uint256" },
          { "internalType": "address", "name": "farmer", "type": "address" }
        ],
        "internalType": "struct SupplyChainTracker.FarmerInfo",
        "name": "farmerInfo",
        "type": "tuple"
      },
      {
        "components": [
          { "internalType": "string", "name": "distributorName", "type": "string" },
          { "internalType": "uint256", "name": "quantityReceived", "type": "uint256" },
          { "internalType": "uint256", "name": "purchasePrice", "type": "uint256" },
          { "internalType": "string", "name": "transportDetails", "type": "string" },
          { "internalType": "string", "name": "warehouseLocation", "type": "string" },
          { "internalType": "uint256", "name": "handoverDate", "type": "uint256" },
          { "internalType": "uint256", "name": "distributedDate", "type": "uint256" },
          { "internalType": "address", "name": "distributor", "type": "address" }
        ],
        "internalType": "struct SupplyChainTracker.DistributorInfo",
        "name": "distributorInfo",
        "type": "tuple"
      },
      {
        "components": [
          { "internalType": "string", "name": "retailerName", "type": "string" },
          { "internalType": "string", "name": "shopLocation", "type": "string" },
          { "internalType": "uint256", "name": "retailQuantity", "type": "uint256" },
          { "internalType": "uint256", "name": "retailPurchasePrice", "type": "uint256" },
          { "internalType": "uint256", "name": "consumerPrice", "type": "uint256" },
          { "internalType": "uint256", "name": "expiryDate", "type": "uint256" },
          { "internalType": "uint256", "name": "retailDate", "type": "uint256" },
          { "internalType": "address", "name": "retailer", "type": "address" }
        ],
        "internalType": "struct SupplyChainTracker.RetailInfo",
        "name": "retailInfo",
        "type": "tuple"
      },
      { "internalType": "enum SupplyChainTracker.Stage", "name": "stage", "type": "uint8" }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "uint256", "name": "batchId", "type": "uint256" },
      { "internalType": "string", "name": "distributorName", "type": "string" },
      { "internalType": "uint256", "name": "quantityReceived", "type": "uint256" },
      { "internalType": "uint256", "name": "purchasePrice", "type": "uint256" },
      { "internalType": "string", "name": "transportDetails", "type": "string" },
      { "internalType": "string", "name": "warehouseLocation", "type": "string" },
      { "internalType": "uint256", "name": "handoverDate", "type": "uint256" }
    ],
    "name": "updateDistribution",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "uint256", "name": "batchId", "type": "uint256" },
      { "internalType": "string", "name": "retailerName", "type": "string" },
      { "internalType": "string", "name": "shopLocation", "type": "string" },
      { "internalType": "uint256", "name": "retailQuantity", "type": "uint256" },
      { "internalType": "uint256", "name": "retailPurchasePrice", "type": "uint256" },
      { "internalType": "uint256", "name": "consumerPrice", "type": "uint256" },
      { "internalType": "uint256", "name": "expiryDate", "type": "uint256" }
    ],
    "name": "updateRetail",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  }
];

