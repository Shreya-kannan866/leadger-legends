// eth.js — read-only provider + contract
require('dotenv').config();
const { ethers } = require('ethers');
const abi = require('./abi');

if (!process.env.NETWORK_RPC) throw new Error('NETWORK_RPC not set in .env');
if (!process.env.CONTRACT_ADDRESS) throw new Error('CONTRACT_ADDRESS not set in .env');

const provider = new ethers.JsonRpcProvider(process.env.NETWORK_RPC);
const contract = new ethers.Contract(process.env.CONTRACT_ADDRESS, abi, provider);

module.exports = { provider, contract, ethers };

